// Example: Extract a suffix from backend state
return {
  stateValueWithDefault:
    state.randomStateValueWithDefault || "State value default",
  stateValueEmpty: state.randomStateValueEmpty,
};
